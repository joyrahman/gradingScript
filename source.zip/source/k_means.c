/*
 * Skeleton function for CS4823 Introduction of Parallel Programming, 
 * Assignment 2: K-Means Algorithm (Sequential)
 *
 * To students: You should not finish the implementation of k_means function
 * 
 * Author:
 *     Wei Wang <wei.wang@utsa.edu>
 */
#include <stdio.h>
#include <float.h>
#include <math.h>
#include <omp.h>

#include "k_means.h"

/*
 * k_means: k_means clustering algorithm implementation.
 *
 * Input parameters:
 *     struct point p[]: array of data points
 *     int m           : number of data points in p[]
 *     int k           : number of clusters to find
 *     int iters       : number of clustering iterations to run
 *
 * Output parameters:   
 *     struct point u[]: array of cluster centers
 *     int c[]         : cluster id for each data points
 */
void k_means(struct point p[MAX_POINTS], 
	    int m, 
	    int k,
	    int iters,
	    struct point u[MAX_CENTERS],
	    int c[MAX_POINTS])
{
	int i,j,l;
	int counts[MAX_CENTERS];
	struct point sum[MAX_CENTERS];
	double min_dist, dist;
	struct point sum_temp[MAX_CENTERS];
	int counts_temp[MAX_CENTERS];

	/* randomly initialized the centers */
	for(j = 0; j < k; j++)
		u[j] = random_center(p);

	/* do k-means cluster "iters" times */
	for(l = 0; l < iters; l++){
		/* assign points to clusters */
                #pragma omp parallel for private(j, min_dist, dist) shared(c, p, u)
		for(i = 0; i < m; i++){
			min_dist = DBL_MAX;
			c[i] = 0;
			for(j = 0; j < k; j++){
				dist =  ((p[i].x - u[j].x)*(p[i].x - u[j].x) +
					    (p[i].y - u[j].y)*(p[i].y - u[j].y));
				       
				if(dist < min_dist){
					c[i] = j;
					min_dist = dist;
				}
			}
		}
		
		
		/* find the new centers */
                #pragma omp parallel for shared(sum, counts)
		for(j = 0; j < k; j++){
			sum[j].x = sum[j].y = 0;
			counts[j] = 0;
		}
		
                #pragma omp parallel shared(p,c,sum) private(j, sum_temp, counts_temp)
		{
			for(j = 0; j < k; j++){
				sum_temp[j].x = sum_temp[j].y = 0;
				counts_temp[j] = 0;
			}

			#pragma omp for
			for(i = 0; i < m; i++){
				sum_temp[c[i]].x += p[i].x;
				sum_temp[c[i]].y += p[i].y;
				counts_temp[c[i]]++;
			}


			#pragma omp critical
			{
				for(j = 0; j < k; j++){
					sum[j].x += sum_temp[j].x;
					sum[j].y += sum_temp[j].y;
					counts[j] += counts_temp[j];
				}
			}
		}

       
                #pragma omp parallel for shared(u, counts, sum)
		for(j = 0; j < k; j++){
			if(counts[j] != 0){
				u[j].x = sum[j].x / counts[j];
				u[j].y = sum[j].y / counts[j];
			}
			else
				u[j] = random_center(p);
		}
	}	
	
	return;
}
