import subprocess
import os

os.environ['OMP_NUM_THREADS']="4"
output = subprocess.check_output(['./run_adhoc_cmd.sh 8'],shell=True, stderr=subprocess.STDOUT)
print output
